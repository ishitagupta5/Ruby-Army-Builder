# Squad.rb
require_relative 'EnhancedUnit'

class Squad < EnhancedUnit
  def initialize(name)
    super(name, 0)
    @units = []
  end

  def add_unit(unit)
    @units << unit
  end

  def remove_unit(unit)
    @units.delete(unit)
  end

  def getPoints
    @units.sum(&:getPoints)
  end

  def to_s
    s = "#{@name} (#{getPoints}, #{@quality}, #{@defense})"
    if @units.any?
      unit_list = @units.map(&:to_s).join(' ')
      s + " units: #{unit_list} "
    else
      s
    end
  end
end
