# Unit.rb
require_relative 'GameElement'

class Unit
  include GameElement

  attr_accessor :name, :points, :quality, :defense
  attr_reader   :upgrades

  def initialize(name, points)
    @name     = name
    @points   = points.to_i
    @quality  = 2
    @defense  = 2
    @upgrades = []
  end

  # GameElement API
  def getName
    @name
  end

  def getPoints
    @points + @upgrades.sum(&:getPoints)
  end

  def addUpgrade(upgrade)
    @upgrades << upgrade
  end

  def removeUpgrade(upgrade)
    @upgrades.delete(upgrade)
  end

  def to_s
    base = "#{@name} (#{getPoints}, #{@quality}, #{@defense})"
    if @upgrades.any?
      u_str = @upgrades.map(&:to_s).join(', ')
      base + " upgrades: [#{u_str}]"
    else
      base
    end
  end
end
