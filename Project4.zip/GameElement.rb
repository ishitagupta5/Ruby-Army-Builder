
module GameElement

  def getName
    raise "Not Implemented"
  end

  def getPoints
    raise "Not Implemented"
  end

end
