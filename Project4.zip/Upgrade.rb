# Upgrade.rb
require_relative 'GameElement'

class Upgrade
  include GameElement

  def initialize(name, points)
    @name   = name
    @points = points.to_i
  end

  # GameElement API
  def getName
    @name
  end

  def getPoints
    @points
  end

  def to_s
    "#{@name} (#{@points})"
  end
end
